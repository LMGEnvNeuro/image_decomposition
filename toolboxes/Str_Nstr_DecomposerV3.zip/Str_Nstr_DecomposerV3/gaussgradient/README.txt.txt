GAUSSGRADIENT Gradient using first order derivative of Gaussian.
  [gx,gy]=gaussgradient(IM,sigma) outputs the gradient image gx and gy of
  image IM using a 2-D Gaussian kernel. Sigma is the standard deviation of
  this kernel along both directions.

  Contributed by Guanglei Xiong (xgl99@mails.tsinghua.edu.cn)
  at Tsinghua University, Beijing, China.

Please try testgrassgradient.m first!